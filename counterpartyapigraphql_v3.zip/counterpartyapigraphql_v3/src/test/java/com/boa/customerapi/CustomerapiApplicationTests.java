package com.boa.customerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
