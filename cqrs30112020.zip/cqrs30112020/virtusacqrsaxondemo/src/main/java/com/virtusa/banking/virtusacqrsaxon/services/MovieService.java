package com.virtusa.banking.virtusacqrsaxon.services;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.axonframework.eventhandling.EventHandler;
import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.virtusacqrsaxon.events.MovieCreatedEvent;
import com.virtusa.banking.virtusacqrsaxon.models.MovieBean;
import com.virtusa.banking.virtusacqrsaxon.models.MovieEntity;
import com.virtusa.banking.virtusacqrsaxon.queries.GetMoviesQuery;
import com.virtusa.banking.virtusacqrsaxon.repository.MovieRepository;

@Service
public class MovieService {
	@Autowired
	private MovieRepository movieRepository;

	
	@EventHandler
	public void addMovie(MovieCreatedEvent event) throws Exception {
		MovieEntity movie = new MovieEntity();
		movie.setRegNo(event.getRegNo());
		movie.setMovieId(event.getMovieId());
		movie.setHero(event.getHero());
		movie.setMovieName(event.getMovieName());
		movieRepository.save(movie);
	}

	@QueryHandler
	public List<MovieBean> getMovies(GetMoviesQuery query) {
		return movieRepository.findByRegNo(query.getRegNo())
				.stream().map(toMovie()).collect(Collectors.toList());
	}

	private Function<MovieEntity, MovieBean> toMovie() {
		return e -> {
			MovieBean movie = new MovieBean();
			movie.setMovieId(e.getMovieId());
			movie.setMovieName(e.getMovieName());
			movie.setHero(e.getHero());
			return movie;
		};
	}

}
