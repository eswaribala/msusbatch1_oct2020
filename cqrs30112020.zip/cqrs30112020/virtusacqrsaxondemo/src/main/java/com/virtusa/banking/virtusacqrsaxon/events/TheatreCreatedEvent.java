package com.virtusa.banking.virtusacqrsaxon.events;

import lombok.Data;

@Data
public class TheatreCreatedEvent {

	private final Integer regNo;
	private final String name;

}
