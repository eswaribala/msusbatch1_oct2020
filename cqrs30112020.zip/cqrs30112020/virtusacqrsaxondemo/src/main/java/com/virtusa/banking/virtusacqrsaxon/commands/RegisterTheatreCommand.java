package com.virtusa.banking.virtusacqrsaxon.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class RegisterTheatreCommand {
	@TargetAggregateIdentifier
	private final Integer regNo;

	private final String name;
}
