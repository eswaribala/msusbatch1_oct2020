package com.virtusa.banking.virtusacqrsaxon.models;

import lombok.Data;

@Data
public class TheatreBean {

	private int regNo;
	private String name;
}
