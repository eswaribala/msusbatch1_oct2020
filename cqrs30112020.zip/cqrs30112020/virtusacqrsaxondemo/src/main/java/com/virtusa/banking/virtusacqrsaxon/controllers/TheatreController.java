package com.virtusa.banking.virtusacqrsaxon.controllers;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.virtusacqrsaxon.aggregators.Theatre;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterTheatreCommand;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterMovieCommand;
import com.virtusa.banking.virtusacqrsaxon.models.TheatreBean;
import com.virtusa.banking.virtusacqrsaxon.models.MovieBean;
import com.virtusa.banking.virtusacqrsaxon.queries.GetTheatresQuery;
import com.virtusa.banking.virtusacqrsaxon.queries.GetMoviesQuery;

@RestController
public class TheatreController {

	private final CommandGateway commandGateway;
	private final QueryGateway queryGateway;

	@Autowired
	public TheatreController(CommandGateway commandGateway, QueryGateway queryGateway) {
		this.commandGateway = commandGateway;
		this.queryGateway = queryGateway;
	}

	@PostMapping("/api/theatre")
	public String addTheatre(@RequestBody TheatreBean theatre) {
		commandGateway.send(new RegisterTheatreCommand(theatre.getRegNo(), theatre.getName()));
		return "Saved";
	}

	@GetMapping("/api/theatre/{regNo}")
	public Theatre getTheatre(@PathVariable Integer regNo) throws InterruptedException, ExecutionException {
		CompletableFuture<Theatre> future = queryGateway.query(
				new GetTheatresQuery(regNo), Theatre.class);
		return future.get();
	}

	@PostMapping("/api/theatre/{regNo}/movie")
	public String addMovie(@PathVariable Integer regNo, @RequestBody MovieBean movie) {
		commandGateway.send(new RegisterMovieCommand(regNo, movie.getMovieId(), 
				movie.getMovieName(),movie.getHero()));
		return "Saved";
	}

	@GetMapping("/api/theatre/{regNo}/movie")
	public List<MovieBean> getMovie(@PathVariable Integer regNo) throws InterruptedException, ExecutionException {
		return queryGateway.query(new GetMoviesQuery(regNo), 
				ResponseTypes.multipleInstancesOf(MovieBean.class)).get();
	}


}
