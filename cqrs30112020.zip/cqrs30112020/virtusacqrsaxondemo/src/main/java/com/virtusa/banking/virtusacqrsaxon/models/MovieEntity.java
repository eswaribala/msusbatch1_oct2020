package com.virtusa.banking.virtusacqrsaxon.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
@Data
@Entity
public class MovieEntity {
	@Id
	@Column(name="Movie_Id")
	private int movieId;
	@Column(name="Movie_Name",nullable = false,length = 50)
	private String movieName;
	@Column(name="Hero",nullable = false,length = 50)
	private String hero;
	@Column(name="Reg_No")
	private int regNo;
}
