package com.virtusa.banking.virtusacqrsaxon.aggregators;

import java.util.ArrayList;
import java.util.List;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.util.Assert;

import com.virtusa.banking.virtusacqrsaxon.commands.RegisterTheatreCommand;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterMovieCommand;
import com.virtusa.banking.virtusacqrsaxon.events.TheatreCreatedEvent;
import com.virtusa.banking.virtusacqrsaxon.events.MovieCreatedEvent;

@Aggregate
public class Theatre {
	@AggregateIdentifier
	private Integer regNo;

	private String name;

	private List<Integer> movies;

	protected Theatre() {
		// For Axon instantiation
	}

	@CommandHandler
	public Theatre(RegisterTheatreCommand cmd) {
		Assert.notNull(cmd.getRegNo(), "ID should not be null");
		Assert.notNull(cmd.getName(), "Name should not be null");

		AggregateLifecycle.apply(new TheatreCreatedEvent
				(cmd.getRegNo(), cmd.getName()));
	}

	public Integer getRegNo() {
		return regNo;
	}

	public String getName() {
		return name;
	}

	public List<Integer> getMovies() {
		return movies;
	}

	@CommandHandler
	public void addMovie(RegisterMovieCommand cmd) {
		Assert.notNull(cmd.getRegNo(), "ID should not be null");
		Assert.notNull(cmd.getMovieId(), "Movie should not be null");

		AggregateLifecycle.apply(new MovieCreatedEvent
				(cmd.getRegNo(), cmd.getMovieId(), 
						cmd.getMovieName(),cmd.getHero()));
	}

	@EventSourcingHandler
	private void handleCreatedEvent(TheatreCreatedEvent event) {
		regNo = event.getRegNo();
		name = event.getName();
		movies = new ArrayList<>();
	}

	@EventSourcingHandler
	private void addMovie(MovieCreatedEvent event) {
		movies.add(event.getMovieId());
	}

}
