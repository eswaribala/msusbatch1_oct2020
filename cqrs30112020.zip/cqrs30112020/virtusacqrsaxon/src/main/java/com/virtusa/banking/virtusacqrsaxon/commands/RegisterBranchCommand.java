package com.virtusa.banking.virtusacqrsaxon.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class RegisterBranchCommand {
	@TargetAggregateIdentifier
	private final Integer bankId;
	private final int branchId;
	private final String branchName;
	private final String address;
}
