package com.virtusa.banking.virtusacqrsaxon.controllers;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.virtusacqrsaxon.aggregators.Bank;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterBankCommand;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterBranchCommand;
import com.virtusa.banking.virtusacqrsaxon.models.BankBean;
import com.virtusa.banking.virtusacqrsaxon.models.BranchBean;
import com.virtusa.banking.virtusacqrsaxon.queries.GetBanksQuery;
import com.virtusa.banking.virtusacqrsaxon.queries.GetBranchesQuery;

@RestController
public class BankController {

	private final CommandGateway commandGateway;
	private final QueryGateway queryGateway;

	@Autowired
	public BankController(CommandGateway commandGateway, QueryGateway queryGateway) {
		this.commandGateway = commandGateway;
		this.queryGateway = queryGateway;
	}

	@PostMapping("/api/bank")
	public String addLibrary(@RequestBody BankBean bank) {
		commandGateway.send(new RegisterBankCommand(bank.getBankId(), bank.getBankName()));
		return "Saved";
	}

	@GetMapping("/api/bank/{bankId}")
	public Bank getLibrary(@PathVariable Integer bankId) throws InterruptedException, ExecutionException {
		CompletableFuture<Bank> future = queryGateway.query(new GetBanksQuery(bankId), Bank.class);
		return future.get();
	}

	@PostMapping("/api/bank/{bankId}/branch")
	public String addBook(@PathVariable Integer bankId, @RequestBody BranchBean branch) {
		commandGateway.send(new RegisterBranchCommand(bankId, branch.getBranchId(), branch.getBranchName(),branch.getAddress()));
		return "Saved";
	}

	@GetMapping("/api/bank/{bankId}/branch")
	public List<BranchBean> addBook(@PathVariable Integer bankId) throws InterruptedException, ExecutionException {
		return queryGateway.query(new GetBranchesQuery(bankId), ResponseTypes.multipleInstancesOf(BranchBean.class)).get();
	}


}
