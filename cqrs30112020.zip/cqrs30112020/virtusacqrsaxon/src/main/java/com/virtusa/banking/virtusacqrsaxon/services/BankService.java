package com.virtusa.banking.virtusacqrsaxon.services;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.axonframework.queryhandling.QueryHandler;
import org.axonframework.modelling.command.Repository;

import org.springframework.stereotype.Service;

import com.virtusa.banking.virtusacqrsaxon.aggregators.Bank;
import com.virtusa.banking.virtusacqrsaxon.queries.GetBanksQuery;

@Service
public class BankService {
	
	private final Repository<Bank> bankRepository;

	public BankService(Repository<Bank> bankRepository) {
		this.bankRepository = bankRepository;
	}

	@QueryHandler
	public Bank getLibrary(GetBanksQuery query) throws InterruptedException, ExecutionException {
		CompletableFuture<Bank> future = new CompletableFuture<Bank>();
		bankRepository.load(""+query.getBankId()).execute(future::complete);
		return future.get();
	}



}
