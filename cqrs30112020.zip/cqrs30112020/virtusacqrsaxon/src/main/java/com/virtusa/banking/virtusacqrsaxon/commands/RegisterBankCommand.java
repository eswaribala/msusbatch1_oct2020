package com.virtusa.banking.virtusacqrsaxon.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class RegisterBankCommand {
	@TargetAggregateIdentifier
	private final Integer bankId;

	private final String bankName;
}
