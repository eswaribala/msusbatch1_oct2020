package com.virtusa.banking.virtusacqrsaxon.aggregators;

import java.util.ArrayList;
import java.util.List;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.util.Assert;

import com.virtusa.banking.virtusacqrsaxon.commands.RegisterBankCommand;
import com.virtusa.banking.virtusacqrsaxon.commands.RegisterBranchCommand;
import com.virtusa.banking.virtusacqrsaxon.events.BankCreatedEvent;
import com.virtusa.banking.virtusacqrsaxon.events.BranchCreatedEvent;

@Aggregate
public class Bank {
	@AggregateIdentifier
	private Integer bankId;

	private String bankName;

	private List<Integer> branches;

	protected Bank() {
		// For Axon instantiation
	}

	@CommandHandler
	public Bank(RegisterBankCommand cmd) {
		Assert.notNull(cmd.getBankId(), "ID should not be null");
		Assert.notNull(cmd.getBankName(), "Name should not be null");

		AggregateLifecycle.apply(new BankCreatedEvent(cmd.getBankId(), cmd.getBankName()));
	}

	public Integer getBankId() {
		return bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public List<Integer> getBranches() {
		return branches;
	}

	@CommandHandler
	public void addranch(RegisterBranchCommand cmd) {
		Assert.notNull(cmd.getBankId(), "ID should not be null");
		Assert.notNull(cmd.getBranchId(), "Branch should not be null");

		AggregateLifecycle.apply(new BranchCreatedEvent(cmd.getBankId(), cmd.getBranchId(), cmd.getBranchName(),cmd.getAddress()));
	}

	@EventSourcingHandler
	private void handleCreatedEvent(BankCreatedEvent event) {
		bankId = event.getBankId();
		bankName = event.getBankName();
		branches = new ArrayList<>();
	}

	@EventSourcingHandler
	private void addBook(BranchCreatedEvent event) {
		branches.add(event.getBranchId());
	}

}
