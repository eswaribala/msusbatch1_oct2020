package com.virtusa.banking.virtusacqrsaxon.events;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class BranchCreatedEvent {

	@TargetAggregateIdentifier
	private final Integer bankId;
	private final int branchId;
	private final String branchName;
	private final String address;

}
