package com.virtusa.banking.virtusacqrsaxon.queries;

import lombok.Data;

@Data
public class GetBanksQuery {
	private final Integer bankId;

}
