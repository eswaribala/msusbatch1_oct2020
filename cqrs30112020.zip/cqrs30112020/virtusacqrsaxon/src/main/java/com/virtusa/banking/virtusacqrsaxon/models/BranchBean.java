package com.virtusa.banking.virtusacqrsaxon.models;

import lombok.Data;

@Data
public class BranchBean {

	private int branchId;
	private String branchName;
	private String address;
}
