package com.virtusa.banking.virtusacqrsaxon.services;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.axonframework.eventhandling.EventHandler;
import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.virtusacqrsaxon.events.BranchCreatedEvent;
import com.virtusa.banking.virtusacqrsaxon.models.BranchBean;
import com.virtusa.banking.virtusacqrsaxon.models.BranchEntity;
import com.virtusa.banking.virtusacqrsaxon.queries.GetBranchesQuery;
import com.virtusa.banking.virtusacqrsaxon.repository.BranchRepository;

@Service
public class BranchService {
	@Autowired
	private BranchRepository branchRepository;

	
	@EventHandler
	public void addBook(BranchCreatedEvent event) throws Exception {
		BranchEntity branch = new BranchEntity();
		branch.setBankId(event.getBankId());
		branch.setBranchId(event.getBranchId());
		branch.setAddress(event.getAddress());
		branch.setBranchName(event.getBranchName());
		branchRepository.save(branch);
	}

	@QueryHandler
	public List<BranchBean> getBranches(GetBranchesQuery query) {
		return branchRepository.findByBankId(query.getBankId()).stream().map(toBranch()).collect(Collectors.toList());
	}

	private Function<BranchEntity, BranchBean> toBranch() {
		return e -> {
			BranchBean branch = new BranchBean();
			branch.setBranchId(e.getBranchId());
			branch.setBranchName(e.getBranchName());
			branch.setAddress(e.getAddress());
			return branch;
		};
	}

}
