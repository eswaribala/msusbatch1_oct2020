package com.virtusa.banking.virtusacqrsaxon.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
@Data
@Entity
public class BranchEntity {
	@Id
	@Column(name="Branch_Id")
	private int branchId;
	@Column(name="Branch_Name",nullable = false,length = 50)
	private String branchName;
	@Column(name="Address",nullable = false,length = 50)
	private String address;
	@Column(name="Bank_Id")
	private int bankId;
}
