package com.virtusa.banking.virtusacqrsaxon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.banking.virtusacqrsaxon.models.BranchBean;
import com.virtusa.banking.virtusacqrsaxon.models.BranchEntity;

public interface BranchRepository extends JpaRepository<BranchEntity,Integer> {

	List<BranchEntity> findByBankId(Integer bankId);

}
