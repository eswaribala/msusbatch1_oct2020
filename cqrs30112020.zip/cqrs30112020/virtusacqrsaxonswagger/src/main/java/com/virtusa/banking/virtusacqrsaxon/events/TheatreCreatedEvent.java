package com.virtusa.banking.virtusacqrsaxon.events;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class TheatreCreatedEvent {
    
	private final Integer regNo;
	private final String name;

}
