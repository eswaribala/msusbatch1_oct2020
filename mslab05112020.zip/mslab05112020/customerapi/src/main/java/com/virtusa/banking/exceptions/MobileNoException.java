package com.virtusa.banking.exceptions;

public class MobileNoException extends RuntimeException {
	
	public MobileNoException(String message)
	{
		super(message);
	}

}
