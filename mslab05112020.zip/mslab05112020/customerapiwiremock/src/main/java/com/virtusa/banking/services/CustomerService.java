package com.virtusa.banking.services;



import java.util.List;

import com.virtusa.banking.models.Customer;

public interface CustomerService {
    List<Customer> getAllCustomers();
}
