package com.virtusa.banking.models;



import lombok.Data;
//value object
@Data
public class FullName {
	
	
	private String firstName;
	
	private String lastName;
	
	private String middleName;

}
