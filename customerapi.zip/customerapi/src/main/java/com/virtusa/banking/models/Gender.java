package com.virtusa.banking.models;

public enum Gender {
 MALE,FEMALE,TRANSGENDER
}
